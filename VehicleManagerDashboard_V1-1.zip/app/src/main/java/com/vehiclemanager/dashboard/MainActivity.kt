package com.vehiclemanager.dashboard

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Blue = Color(0xFF1565C0)
private val LightBlue = Color(0xFFEAF3FF)
private val Green = Color(0xFF2E7D32)
private val Orange = Color(0xFFEF6C00)
private val Red = Color(0xFFC62828)
private val Background = Color(0xFFF6F8FB)

data class Vehicle(
    val number: String,
    val driver: String,
    val lastWork: String,
    val nextWork: String,
    val status: String = "চলমান"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            VehicleManagerTheme {
                VehicleManagerApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VehicleManagerApp() {
    var selectedTab by remember { mutableIntStateOf(0) }
    var showAddVehicle by remember { mutableStateOf(false) }

    val vehicles = remember {
        mutableStateListOf(
            Vehicle("ঢাকা মেট্রো-গ-১২-৩৪৫৬", "মো. রহিম", "১৫ আগস্ট ২০২৬", "১৫ নভেম্বর ২০২৬"),
            Vehicle("ঢাকা মেট্রো-গ-২৫-৭৮৯০", "মো. করিম", "০৮ আগস্ট ২০২৬", "০৮ নভেম্বর ২০২৬"),
            Vehicle("ঢাকা মেট্রো-খ-১৮-৪৫৬৭", "মো. সোহেল", "২৮ জুলাই ২০২৬", "২৮ অক্টোবর ২০২৬")
        )
    }

    Scaffold(
        containerColor = Background,
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        "Vehicle Manager",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = {}) {
                        Icon(Icons.Default.Menu, contentDescription = "মেনু")
                    }
                },
                actions = {
                    IconButton(onClick = {}) {
                        Icon(Icons.Default.Notifications, contentDescription = "নোটিফিকেশন")
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color.White
                )
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Home, null) },
                    label = { Text("হোম") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.DirectionsCar, null) },
                    label = { Text("গাড়ি") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Build, null) },
                    label = { Text("কাজ") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.BarChart, null) },
                    label = { Text("রিপোর্ট") }
                )
            }
        },
        floatingActionButton = {
            if (selectedTab == 0 || selectedTab == 1) {
                FloatingActionButton(
                    onClick = { showAddVehicle = true },
                    containerColor = Blue,
                    contentColor = Color.White
                ) {
                    Icon(Icons.Default.Add, contentDescription = "নতুন গাড়ি")
                }
            }
        }
    ) { padding ->
        when (selectedTab) {
            0 -> DashboardScreen(
                modifier = Modifier.padding(padding),
                vehicles = vehicles,
                onAddVehicle = { showAddVehicle = true }
            )
            1 -> VehicleListScreen(
                modifier = Modifier.padding(padding),
                vehicles = vehicles,
                onAddVehicle = { showAddVehicle = true }
            )
            2 -> PlaceholderScreen(
                modifier = Modifier.padding(padding),
                icon = Icons.Default.Build,
                title = "কাজের হিসাব",
                message = "পরের ধাপে এখানে সার্ভিস ও মেরামতের History যুক্ত হবে।"
            )
            else -> PlaceholderScreen(
                modifier = Modifier.padding(padding),
                icon = Icons.Default.BarChart,
                title = "রিপোর্ট",
                message = "পরের ধাপে মাসিক ও বার্ষিক রিপোর্ট যুক্ত হবে।"
            )
        }
    }

    if (showAddVehicle) {
        AddVehicleDialog(
            onDismiss = { showAddVehicle = false },
            onSave = { number, driver ->
                vehicles.add(
                    0,
                    Vehicle(
                        number = number,
                        driver = driver,
                        lastWork = "নতুন গাড়ি",
                        nextWork = "তারিখ সেট করা হয়নি"
                    )
                )
                showAddVehicle = false
            }
        )
    }
}

@Composable
fun DashboardScreen(
    modifier: Modifier = Modifier,
    vehicles: List<Vehicle>,
    onAddVehicle: () -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                "স্বাগতম 👋",
                fontSize = 25.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                "আপনার গাড়ির সব তথ্য এক জায়গায় পরিচালনা করুন",
                color = Color.Gray,
                fontSize = 14.sp
            )
        }

        item {
            SummaryGrid()
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("আমার গাড়ি", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text(
                    "সবগুলো দেখুন",
                    color = Blue,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { }
                )
            }
        }

        items(vehicles.take(3)) { vehicle ->
            VehicleCard(vehicle)
        }

        item {
            Button(
                onClick = onAddVehicle,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.width(8.dp))
                Text("নতুন গাড়ি যোগ করুন", fontSize = 16.sp)
            }
        }

        item {
            Text("সতর্কতা", fontSize = 19.sp, fontWeight = FontWeight.Bold)
        }

        item {
            AlertCard(
                icon = Icons.Default.Description,
                title = "২টি গাড়ির কাগজের মেয়াদ শীঘ্রই শেষ হবে",
                subtitle = "ডকুমেন্ট বিভাগ থেকে বিস্তারিত দেখুন",
                color = Orange
            )
        }

        item {
            AlertCard(
                icon = Icons.Default.Gavel,
                title = "১টি মামলা নিষ্পত্তি করা বাকি",
                subtitle = "মামলা বিভাগ থেকে বিস্তারিত দেখুন",
                color = Red
            )
        }
    }
}

@Composable
fun SummaryGrid() {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SummaryCard("মোট গাড়ি", "১২", Icons.Default.DirectionsCar, Blue, Modifier.weight(1f))
            SummaryCard("ড্রাইভার", "১০", Icons.Default.Person, Green, Modifier.weight(1f))
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SummaryCard("এই মাসের কাজ", "১৮", Icons.Default.Build, Orange, Modifier.weight(1f))
            SummaryCard("মামলা", "০৩", Icons.Default.Gavel, Red, Modifier.weight(1f))
        }
    }
}

@Composable
fun SummaryCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(iconColor.copy(alpha = 0.12f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, null, tint = iconColor)
            }
            Text(title, color = Color.Gray, fontSize = 13.sp)
            Text(value, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun VehicleCard(vehicle: Vehicle) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(LightBlue, RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.DirectionsCar, null, tint = Blue)
                }
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        vehicle.number,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text("ড্রাইভার: ${vehicle.driver}", color = Color.Gray, fontSize = 13.sp)
                }
                AssistChip(
                    onClick = {},
                    label = { Text(vehicle.status) },
                    leadingIcon = {
                        Icon(Icons.Default.CheckCircle, null, modifier = Modifier.size(16.dp))
                    },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = Color(0xFFE8F5E9),
                        labelColor = Green,
                        leadingIconContentColor = Green
                    )
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                InfoItem(
                    modifier = Modifier.weight(1f),
                    label = "শেষ কাজ",
                    value = vehicle.lastWork,
                    icon = Icons.Default.Build
                )
                InfoItem(
                    modifier = Modifier.weight(1f),
                    label = "পরবর্তী কাজ",
                    value = vehicle.nextWork,
                    icon = Icons.Default.Event
                )
            }
        }
    }
}

@Composable
fun InfoItem(
    modifier: Modifier,
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Row(modifier = modifier, verticalAlignment = Alignment.Top) {
        Icon(icon, null, tint = Blue, modifier = Modifier.size(19.dp))
        Spacer(Modifier.width(7.dp))
        Column {
            Text(label, color = Color.Gray, fontSize = 12.sp)
            Text(value, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        }
    }
}

@Composable
fun AlertCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    color: Color
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.08f))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, null, tint = color, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text(subtitle, color = Color.Gray, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun VehicleListScreen(
    modifier: Modifier,
    vehicles: List<Vehicle>,
    onAddVehicle: () -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("গাড়ির তালিকা", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                IconButton(onClick = onAddVehicle) {
                    Icon(Icons.Default.Add, "নতুন গাড়ি")
                }
            }
        }
        items(vehicles) { vehicle ->
            VehicleCard(vehicle)
        }
    }
}

@Composable
fun PlaceholderScreen(
    modifier: Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    message: String
) {
    Box(
        modifier = modifier.fillMaxSize().padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(64.dp))
            Spacer(Modifier.height(16.dp))
            Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(message, color = Color.Gray)
        }
    }
}

@Composable
fun AddVehicleDialog(
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var number by remember { mutableStateOf("") }
    var driver by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন গাড়ি যোগ করুন", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = number,
                    onValueChange = { number = it },
                    label = { Text("গাড়ির নম্বর") },
                    placeholder = { Text("যেমন: ঢাকা মেট্রো-গ-১২-৩৪৫৬") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = driver,
                    onValueChange = { driver = it },
                    label = { Text("ড্রাইভারের নাম") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { if (number.isNotBlank()) onSave(number, driver.ifBlank { "নির্ধারিত নয়" }) },
                enabled = number.isNotBlank()
            ) {
                Text("সংরক্ষণ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("বাতিল") }
        }
    )
}

@Composable
fun VehicleManagerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue,
            secondary = Green,
            background = Background,
            surface = Color.White
        ),
        typography = Typography(),
        content = content
    )
}
