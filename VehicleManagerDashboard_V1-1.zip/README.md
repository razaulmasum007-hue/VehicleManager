# Vehicle Manager — Dashboard V1

এটি Android Studio-তে চালানোর জন্য একটি Kotlin + Jetpack Compose starter project।

## চালানোর নিয়ম

1. ZIP ফাইলটি Extract করুন।
2. Android Studio খুলুন।
3. `VehicleManagerDashboard` ফোল্ডারটি Open করুন।
4. Gradle Sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন।
5. Android Emulator বা USB debugging চালু করা Android ফোন নির্বাচন করুন।
6. Run ▶ চাপুন।

## V1 Dashboard-এ আছে

- Dashboard summary cards
- Vehicle list
- Add Vehicle dialog
- Basic vehicle cards
- Warning cards
- Bottom navigation
- কাজ ও রিপোর্টের placeholder screen

## গুরুত্বপূর্ণ

এটি V1-এর UI/functional prototype। এখনো permanent database, document photo storage, মামলা database, notification এবং cloud backup যুক্ত করা হয়নি। পরের ধাপে এগুলো যুক্ত করা যাবে।
